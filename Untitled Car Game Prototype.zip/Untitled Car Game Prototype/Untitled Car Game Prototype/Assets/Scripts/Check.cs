﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Check : MonoBehaviour
{
    Renderer CheckRenderer;
    // Start is called before the first frame update
    void Start()
    {
        CheckRenderer = GetComponent<Renderer>();
        CheckRenderer.material.color = new Color32(0, 255, 0, 255);
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.tag == "Car")
        {
            CheckRenderer.material.color = new Color32(255, 0, 0, 255);
        }
        if (other.tag == "Car2")
        {
            CheckRenderer.material.color = new Color32(0, 0,255, 255);
        }
    }
}
