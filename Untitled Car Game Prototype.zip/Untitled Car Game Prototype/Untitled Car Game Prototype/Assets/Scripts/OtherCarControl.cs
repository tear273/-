﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class OtherCarControl : MonoBehaviour
{
    public bool wasd;

    public WheelCollider FrontLeft;
    public WheelCollider FrontRight;
    public WheelCollider RearLeft;
    public WheelCollider RearRight;

    WheelFrictionCurve fFrictionRWL;
    WheelFrictionCurve sFrictionRWL;
    WheelFrictionCurve fFrictionRWR;
    WheelFrictionCurve sFrictionRWR;

    public float maxMotorTorque;
    public float maxSteeringAngle;

    float slipRate = 1.0f;
    float handBreakSlipRate = 0.5f;

    void Start()
    {
        fFrictionRWL = RearLeft.forwardFriction;
        sFrictionRWL = RearLeft.sidewaysFriction;
        fFrictionRWR = RearRight.forwardFriction;
        sFrictionRWR = RearRight.sidewaysFriction;

    }

    void Update()
    {
        if (wasd)
        {
            float motor = maxMotorTorque * Input.GetAxis("Vertical");
            float steering = maxSteeringAngle * Input.GetAxis("Horizontal");

            //Debug.Log(Input.GetAxis("Horizontal"));

            this.FrontLeft.motorTorque = motor;
            this.FrontRight.motorTorque = motor;

            this.FrontLeft.steerAngle = steering;
            this.FrontRight.steerAngle = steering;

        }

        VisualWheel(FrontLeft);
        VisualWheel(FrontRight);
        VisualWheel(RearLeft);
        VisualWheel(RearRight);

        if (Input.GetKey(KeyCode.LeftControl))
        {
            fFrictionRWL.stiffness = handBreakSlipRate;
            RearLeft.forwardFriction = fFrictionRWL;

            sFrictionRWL.stiffness = handBreakSlipRate;
            RearLeft.sidewaysFriction = sFrictionRWL;

            fFrictionRWR.stiffness = handBreakSlipRate;
            RearRight.forwardFriction = fFrictionRWR;

            sFrictionRWR.stiffness = handBreakSlipRate;
            RearRight.sidewaysFriction = sFrictionRWR;
        }
        if (Input.GetKeyUp(KeyCode.LeftControl))
        {
            fFrictionRWL.stiffness = slipRate;
            RearLeft.forwardFriction = fFrictionRWL;

            sFrictionRWL.stiffness = slipRate;
            RearLeft.sidewaysFriction = sFrictionRWL;

            fFrictionRWR.stiffness = slipRate;
            RearRight.forwardFriction = fFrictionRWR;

            sFrictionRWR.stiffness = slipRate;
            RearRight.sidewaysFriction = sFrictionRWR;
        }

    }

    void VisualWheel(WheelCollider collider)
    {
        Transform visualWheel = collider.transform.GetChild(0);

        Vector3 position;
        Quaternion rotation;

        collider.GetWorldPose(out position, out rotation);

        rotation.eulerAngles += new Vector3(0, 0, 90);

        visualWheel.transform.position = position;
        visualWheel.transform.rotation = rotation;
    }

}
