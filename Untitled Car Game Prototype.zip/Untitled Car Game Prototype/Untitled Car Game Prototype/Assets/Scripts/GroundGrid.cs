﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GroundGrid : MonoBehaviour
{
    Transform ground;
    public GameObject CheckBox;

    void Start()
    {
        ground = GetComponent<Transform>();
        Debug.Log(ground.transform.localScale.x);
        Debug.Log(ground.transform.localScale.z);


        MapMake(ground.transform.localScale.x, ground.transform.localScale.z);
    }

    void MapMake(float x, float y)
    {
        float squareX;
        float squareY;

        squareX = x * x;
        squareY = y *y;

        Debug.Log(squareX);
        Debug.Log(squareY);

        for (int i = 0; i < squareX; i +=10)
        {
            for (int j = 0; j < squareY; j += 10)
            {
                Instantiate(CheckBox, new Vector3(-(squareX / 2-5) + i, 0, -(squareY / 2 - 5) + j), Quaternion.identity);
            }
        }
    }
}
